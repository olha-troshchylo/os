#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

double getRandomDouble() {
    return ((double)(rand() % 10001) / 100.0) - 50.0;
}

void printArray(const double* arr, int n) {
    printf("Array: ");
    for (int i = 0; i < n; i++) {
        printf("%.2lf ", arr[i]);
    }
    printf("\n");
}

int main() {
    int n;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Invalid input. Please enter a positive number of elements.\n");
        return 1;
    }

    double* arr = (double*)malloc(n * sizeof(double));
    if (arr == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    srand(time(NULL));
    for (int i = 0; i < n; i++) {
        arr[i] = getRandomDouble();
    }

    printArray(arr, n);

    double sum = 0;
    int count = 0;
    int negativeFound = 0;
    double sumAfterNegative = 0;

    for (int i = 0; i < n; i++) {
        sum += arr[i];

        if (arr[i] > (sum / (i + 1))) {
            count++;
        }

        if (!negativeFound && arr[i] < 0) {
            negativeFound = 1;
        }

        if (negativeFound) {
            sumAfterNegative += fabs(arr[i]);
        }
    }

    printf("Number of elements greater than the average: %d\n", count);
    printf("Sum of absolute values after the first negative element: %.2lf\n", sumAfterNegative);

    free(arr);

    return 0;
}
