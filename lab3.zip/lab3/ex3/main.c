#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int rows;
    int cols;
    double** data;
} Matrix;

Matrix createMatrix(int rows, int cols) {
    Matrix matrix;
    matrix.rows = rows;
    matrix.cols = cols;

    matrix.data = (double**)malloc(rows * sizeof(double*));
    for (int i = 0; i < rows; i++) {
        matrix.data[i] = (double*)malloc(cols * sizeof(double));
    }

    return matrix;
}

void deleteMatrix(Matrix matrix) {
    for (int i = 0; i < matrix.rows; i++) {
        free(matrix.data[i]);
    }
    free(matrix.data);
}

Matrix resizeMatrix(Matrix matrix, int newRows, int newCols) {
    Matrix newMatrix = createMatrix(newRows, newCols);

    int minRows = (matrix.rows < newRows) ? matrix.rows : newRows;
    int minCols = (matrix.cols < newCols) ? matrix.cols : newCols;

    for (int i = 0; i < minRows; i++) {
        for (int j = 0; j < minCols; j++) {
            newMatrix.data[i][j] = matrix.data[i][j];
        }
    }

    return newMatrix;
}

void setElement(Matrix matrix, int row, int col, double value) {
    if (row >= 0 && row < matrix.rows && col >= 0 && col < matrix.cols) {
        matrix.data[row][col] = value;
    }
}

double getElement(Matrix matrix, int row, int col) {
    if (row >= 0 && row < matrix.rows && col >= 0 && col < matrix.cols) {
        return matrix.data[row][col];
    }
    return 0.0; // You can choose a different default value.
}

void printMatrix(Matrix matrix) {
    for (int i = 0; i < matrix.rows; i++) {
        for (int j = 0; j < matrix.cols; j++) {
            printf("%lf\t", matrix.data[i][j]);
        }
        printf("\n");
    }
}

void saveMatrixToFile(Matrix matrix, const char* filename) {
    FILE* file = fopen(filename, "w");

    if (file == NULL) {
        printf("Error opening the file for writing.\n");
        return;
    }

    fprintf(file, "%d %d\n", matrix.rows, matrix.cols);

    for (int i = 0; i < matrix.rows; i++) {
        for (int j = 0; j < matrix.cols; j++) {
            fprintf(file, "%lf ", matrix.data[i][j]);
        }
        fprintf(file, "\n");
    }

    fclose(file);
}

Matrix loadMatrixFromFile(const char* filename) {
    FILE* file = fopen(filename, "r");

    if (file == NULL) {
        printf("Error opening the file for reading.\n");
        Matrix emptyMatrix = createMatrix(0, 0);
        return emptyMatrix;
    }

    int rows, cols;
    fscanf(file, "%d %d", &rows, &cols);

    Matrix matrix = createMatrix(rows, cols);

    for (int i = 0; i < matrix.rows; i++) {
        for (int j = 0; j < matrix.cols; j++) {
            fscanf(file, "%lf", &matrix.data[i][j]);
        }
    }

    fclose(file);
    return matrix;
}

Matrix addMatrices(Matrix matrix1, Matrix matrix2) {
    if (matrix1.rows != matrix2.rows || matrix1.cols != matrix2.cols) {
        printf("Error: Matrices have different sizes.\n");
        return createMatrix(0, 0);
    }

    Matrix result = createMatrix(matrix1.rows, matrix1.cols);

    for (int i = 0; i < matrix1.rows; i++) {
        for (int j = 0; j < matrix1.cols; j++) {
            result.data[i][j] = matrix1.data[i][j] + matrix2.data[i][j];
        }
    }

    return result;
}

Matrix subtractMatrices(Matrix matrix1, Matrix matrix2) {
    if (matrix1.rows != matrix2.rows || matrix1.cols != matrix2.cols) {
        printf("Error: Matrices have different sizes.\n");
        return createMatrix(0, 0);
    }

    Matrix result = createMatrix(matrix1.rows, matrix1.cols);

    for (int i = 0; i < matrix1.rows; i++) {
        for (int j = 0; j < matrix1.cols; j++) {
            result.data[i][j] = matrix1.data[i][j] - matrix2.data[i][j];
        }
    }

    return result;
}

Matrix multiplyMatrixByScalar(Matrix matrix, double scalar) {
    Matrix result = createMatrix(matrix.rows, matrix.cols);

    for (int i = 0; i < matrix.rows; i++) {
        for (int j = 0; j < matrix.cols; j++) {
            result.data[i][j] = matrix.data[i][j] * scalar;
        }
    }

    return result;
}

Matrix multiplyMatrices(Matrix matrix1, Matrix matrix2) {
    if (matrix1.cols != matrix2.rows) {
        printf("Error: Cannot multiply matrices with these dimensions.\n");
        return createMatrix(0, 0);
    }

    Matrix result = createMatrix(matrix1.rows, matrix2.cols);

    for (int i = 0; i < matrix1.rows; i++) {
        for (int j = 0; j < matrix2.cols; j++) {
            result.data[i][j] = 0.0;
            for (int k = 0; k < matrix1.cols; k++) {
                result.data[i][j] += matrix1.data[i][k] * matrix2.data[k][j];
            }
        }
    }

    return result;
}

int main() {
    Matrix matrix1 = createMatrix(3, 3);
    Matrix matrix2 = createMatrix(3, 3);
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            matrix1.data[i][j] = i * 3 + j;
            matrix2.data[i][j] = (i * 3 + j) * 2;
        }
    }
    printf("Matrix 1:\n");
    printMatrix(matrix1);
    printf("\nMatrix 2:\n");
    printMatrix(matrix2);
    setElement(matrix1, 1, 1, 10.0);
    printf("\nMatrix 1 after setting an element:\n");
    printMatrix(matrix1);
    double element = getElement(matrix2, 2, 2);
    printf("\nElement at (2, 2) in Matrix 2: %lf\n", element);
    Matrix resizedMatrix1 = resizeMatrix(matrix1, 2, 2);
    printf("\nResized Matrix 1:\n");
    printMatrix(resizedMatrix1);
    Matrix sum = addMatrices(matrix1, matrix2);
    printf("\nSum of the matrices:\n");
    printMatrix(sum);
    deleteMatrix(sum);
    Matrix difference = subtractMatrices(matrix1, matrix2);
    printf("\nDifference of the matrices:\n");
    printMatrix(difference);
    deleteMatrix(difference);
    double scalar = 2.5;
    Matrix scaledMatrix = multiplyMatrixByScalar(matrix1, scalar);
    printf("\nMatrix 1 multiplied by a scalar:\n");
    printMatrix(scaledMatrix);
    deleteMatrix(scaledMatrix);
    Matrix product = multiplyMatrices(matrix1, matrix2);
    printf("\nProduct of the matrices:\n");
    printMatrix(product);
    deleteMatrix(product);
    saveMatrixToFile(matrix1, "saved_matrix_to_file.txt");
    Matrix loadedMatrix = loadMatrixFromFile("matrix1.txt");
    printf("\nLoaded Matrix from file:\n");
    printMatrix(loadedMatrix);
    deleteMatrix(loadedMatrix);
    deleteMatrix(matrix1);
    deleteMatrix(matrix2);

    return 0;
}


