#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

typedef struct LinkedList {
    Node* head;
    int size;
} LinkedList;

LinkedList* createLinkedList() {
    LinkedList* newList = (LinkedList*)malloc(sizeof(LinkedList));
    if (newList == NULL) {
        perror("Memory allocation error for the list");
        exit(EXIT_FAILURE);
    }
    newList->head = NULL;
    newList->size = 0;
    return newList;
}

Node* createNode(int item) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        perror("Memory allocation error for a new node");
        exit(EXIT_FAILURE);
    }
    newNode->data = item;
    newNode->next = NULL;
    return newNode;
}

void add(LinkedList* list, int item) {
    Node* newNode = createNode(item);

    if (list->head == NULL) {
        list->head = newNode;
    } else {
        Node* current = list->head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
    }

    list->size++;
}

void insert(LinkedList* list, int index, int item) {
    if (index < 0 || index > list->size) {
        fprintf(stderr, "Error: Invalid index for insertion\n");
        return;
    }

    Node* newNode = createNode(item);

    if (index == 0) {
        newNode->next = list->head;
        list->head = newNode;
    } else {
        Node* current = list->head;
        for (int i = 0; i < index - 1; i++) {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }

    list->size++;
}

int size(const LinkedList* list) {
    return list->size;
}

void removeItem(LinkedList* list, int index) {
    if (index < 0 || index >= list->size) {
        fprintf(stderr, "Error: Invalid index for removal\n");
        return;
    }

    Node* temp;
    if (index == 0) {
        temp = list->head;
        list->head = list->head->next;
    } else {
        Node* current = list->head;
        for (int i = 0; i < index - 1; i++) {
            current = current->next;
        }
        temp = current->next;
        current->next = temp->next;
    }

    free(temp);
    list->size--;
}

void set(LinkedList* list, int index, int item) {
    if (index < 0 || index >= list->size) {
        fprintf(stderr, "Error: Invalid index for replacement\n");
        return;
    }

    Node* current = list->head;
    for (int i = 0; i < index; i++) {
        current = current->next;
    }

    current->data = item;
}

int get(const LinkedList* list, int index) {
    if (index < 0 || index >= list->size) {
        fprintf(stderr, "Error: Invalid index for retrieval\n");
        return -1;
    }

    Node* current = list->head;
    for (int i = 0; i < index; i++) {
        current = current->next;
    }

    return current->data;
}

void display(const LinkedList* list) {
    Node* current = list->head;
    while (current != NULL) {
        printf("%d -> ", current->data);
        current = current->next;
    }
    printf("NULL\n");
}

void destroy(LinkedList* list) {
    Node* current = list->head;
    while (current != NULL) {
        Node* temp = current;
        current = current->next;
        free(temp);
    }
    free(list);
}

int main() {
    LinkedList* list = createLinkedList();
    add(list, 1);
    add(list, 2);
    add(list, 3);
    add(list, 4);
    add(list, 5);
    printf("List: ");
    display(list);
    insert(list, 2, 10);
    printf("After insertion: ");
    display(list);
    removeItem(list, 3);
    printf("After removal: ");
    display(list);
    set(list, 1, 7);
    printf("After replacement: ");
    display(list);
    printf("Element at index 2: %d\n", get(list, 2));
    printf("Number of elements in the list: %d\n", size(list));
    destroy(list);
    return 0;
}
