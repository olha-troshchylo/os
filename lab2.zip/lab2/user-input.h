#ifndef OPERATING_SYSTEM_USER_INPUT_H
#define OPERATING_SYSTEM_USER_INPUT_H

int enterBudget();
int enterBet(int budget);
int enterWannaContinue();

#endif //OPERATING_SYSTEM_USER_INPUT_H
