#ifndef OPERATING_SYSTEM_USER_INTERFACE_TEXT_H
#define OPERATING_SYSTEM_USER_INTERFACE_TEXT_H

// Input data messages
void printEnterBudget();

// Game messages
void printYouWinX(int number);
void printReturnYourBet();
void printDoYouWantContinue();
void printYouLose();
void printYourCurrentBudget(int budget);
void printGameOver();
void printThanksForPlaying();

// Error messages
void printEnterCorrectData();
void printNoEnoughMoney();

#endif //OPERATING_SYSTEM_USER_INTERFACE_TEXT_H
