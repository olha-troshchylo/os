#include <stdio.h>
#include <stdlib.h>

#include "user-input.h"
#include "user-interface-text.h"

int enterBudget() {
    char buffer[20];

    while(1) {
        printEnterBudget();
        fflush(stdin);
        fgets(buffer, 20, stdin);

        int budget = atoi(buffer);
        if (budget > 0) {
            return budget;
        } else {
            printEnterCorrectData();
        }
    }
}

int enterBet(int budget) {
    char buffer[20];

    while(1) {
        printf("Enter your bet: ");
        fflush(stdin);
        fgets(buffer, 20, stdin);

        int bet = atoi(buffer);
        if (bet <= 0) {
            printEnterCorrectData();
        } else if (bet > budget) {
            printNoEnoughMoney();
        } else {
            return bet;
        }
    }
}

int enterWannaContinue() {
    char buffer[20];

    while(1) {
        printDoYouWantContinue();
        fflush(stdin);
        fgets(buffer, 20, stdin);

        int choose = atoi(buffer);
        if (choose == 1 || choose == 0) {
            return choose;
        } else {
            printEnterCorrectData();
        }
    }
}
