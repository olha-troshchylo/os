#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "user-input.h"
#include "user-interface-text.h"

int* generateArray(int length);
void printArray(int* array, int length);
int isAllNumbersEqualsNumber(int* array, int length, int number);
int isAllNumbersTheSame(int* array, int length);
int isTwoThirdsNumbersTheSame(int* array, int length);
int isArrayContainsNumber(int* array, int length, int number);

int main() {
    srand(time(NULL));

    int length = 3;

    int budget = enterBudget();

    int play = 1;
    while (play) {
        int bet = enterBet(budget);

        int* array = generateArray(length);
        printArray(array, length);

        if (isAllNumbersEqualsNumber(array, length, 7)) {
            printYouWinX(3);
            budget += bet * 3;
        } else if (isAllNumbersTheSame(array, length)) {
            printYouWinX(2);
            budget += bet * 2;
        } else if (isTwoThirdsNumbersTheSame(array, length) || isArrayContainsNumber(array, length, 7)) {
            printReturnYourBet();
        } else {
            printYouLose();
            budget -= bet;
        }

        printYourCurrentBudget(budget);

        if (budget <= 0) {
            printGameOver();
            play = 0;
        } else {
            int wannaContinue = enterWannaContinue();
            if (wannaContinue == 0) {
                play = 0;
            }
        }
    }

    printThanksForPlaying();
    return 0;
}

int* generateArray(int length) {
    int* array = (int*)malloc(sizeof(int) * length);

    int index;

    for (index = 0; index < length; index++) {
        array[index] = 7; // Ensure that all numbers are 7
    }

    return array;
}

void printArray(int* array, int length) {
    int index;
    for (index = 0; index < length; index++) {
        printf("%d ", array[index]);
    }
    printf("\n");
}

int isAllNumbersEqualsNumber(int* array, int length, int number) {
    int index;

    for (index = 0; index < length; index++) {
        if (array[index] != number) {
            return 0;
        }
    }

    return 1;
}

int isAllNumbersTheSame(int* array, int length) {
    int index;

    for (index = 1; index < length; index++) {
        if (array[index] != array[index - 1]) {
            return 0;
        }
    }

    return 1;
}

int isTwoThirdsNumbersTheSame(int* array, int length) {
    int currentEqualsNumbersCounter = 0;
    int maxNumberEquals = 0;
    int neededNumberEquals = (length * 2) / 3;

    int i;
    for (i = 0; i < length; i++) {
        currentEqualsNumbersCounter = 1; // Start with 1 as we are counting the current number itself

        int j;
        for (j = i + 1; j < length; j++) {
            if (array[i] == array[j]) {
                currentEqualsNumbersCounter++;
            }
        }

        if (maxNumberEquals < currentEqualsNumbersCounter) {
            maxNumberEquals = currentEqualsNumbersCounter;
        }

        currentEqualsNumbersCounter = 0;
    }

    return maxNumberEquals >= neededNumberEquals ? 1 : 0;
}

int isArrayContainsNumber(int* array, int length, int number) {
    int index;

    for (index = 0; index < length; index++) {
        if (array[index] == number) {
            return 1;
        }
    }

    return 0;
}